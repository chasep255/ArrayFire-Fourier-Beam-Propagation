#include <arrayfire.h>
#include <iostream>
#include <cmath>
#include "BeamPropagator.hpp"
#include <unistd.h>
#include <cstring>
#include <vector>
#include <fstream>
#include "modes.hpp"
#include <memory>

const int CELLS = 1024;
const float LAMBDA = 500.0e-9;
const float DZ = LAMBDA * 10;
const float CELL_DIM = LAMBDA;
const int RENDER_EVERY = 30;

void displayModalSpectrum(af::array p)
{
	float avg = af::mean<float>(p);
	float* ph = p.host<float>();
	int lbound = 0, ubound = p.dims(0) - 1;
	for(; lbound < p.dims(0) && ph[lbound] < avg; lbound++);
	for(; ubound > 0 && ph[ubound] < avg; ubound--);
	af::freeHost(ph);
	
	int steps = 2 * p.dims(0);
	p = p(af::seq((double)lbound, (double)ubound));
	af::array x = 2 * af::Pi * af::seq(lbound, ubound + 1) / (steps * DZ);
	af::Window w(2000, 1000);
	while(!w.close())
	{
		w.plot(x, p);
	}
}

void displayTiledModes(const ModesAnalysisConfig& cfg, af::array modes)
{
	std::unique_ptr<BeamPropagator<float>[]> bps(new BeamPropagator<float>[modes.dims(2)]);
	
	for(int i = 0; i < modes.dims(2); i++)
	{
		bps[i] = BeamPropagator<float>(cfg.cell_count, cfg.cell_dim, cfg.lambda);
		bps[i].setMask(cfg.mask);
		bps[i].setElectricField(modes.slice(i));
	}
	
	int cols = std::ceil(std::sqrt(modes.dims(2)));
	int rows = modes.dims(2) / cols;
	rows += rows * cols != modes.dims(2);
	af::Window wnd(cols * cfg.cell_count, rows * cfg.cell_count);
	wnd.grid(rows, cols);
	while(!wnd.close())
	{
		for(int i = 0; i < modes.dims(2); i++)
		{
			bps[i].step(cfg.dz);
		}
		for(int i = 0; i < modes.dims(2); i++)
		{
			af::array tmp = af::abs(bps[i].getElectricField()).as(f32);
			wnd(i / cols, i % cols).image(tmp / af::max<float>(tmp));
		}
		wnd.show();
	}
}

int main()
{
	af::setBackend(AF_BACKEND_CPU);
	af::info();
	
	af::array efld = af::range(CELLS) - CELLS / 2;
	efld *= efld;
	efld = af::tile(efld, 1, CELLS) + af::tile(efld.T(), CELLS);
	efld = af::exp(-efld / 5000.0);
	
	BeamPropagator<float> bp(CELLS, CELL_DIM, LAMBDA);
	bp.setElectricField(efld);
	
	af::array z(500);
	af::array fwhms(500);
	int count = 0;
	bp.step(DZ);
	af::timer start = af::timer::start();
	for(int i = 0; i < 5000; i++)
		bp.step(DZ);
	af::sync();
	double t = af::timer::stop(start);
	
	std::cout << t << std::endl;
	
//	af::Window wnd(CELLS, CELLS);
//	while(!wnd.close() && count < fwhms.dims(0))
//	{
//		efld = af::abs(bp.getElectricField());
//		double m = af::max<double>(efld);
//		int over_half = af::count<int>(efld >= m / (M_E * M_E));
//		double area = over_half * CELL_DIM * CELL_DIM;
//		double fwhm = std::sqrt(area / M_PI);
//		
//		std::cout << bp.getZ() << "," << fwhm << std::endl;
//		z(count) = bp.getZ();
//		fwhms(count) = fwhm;
//		count++;
//		wnd.image((efld > 0.5 * m).as(f32));
//		
//		for(int i = 0; i < 10; i++)
//			bp.step(DZ);
//	}
	
	return 0;
}
