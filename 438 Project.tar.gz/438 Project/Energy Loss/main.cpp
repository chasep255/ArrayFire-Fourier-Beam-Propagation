#include <arrayfire.h>
#include <iostream>
#include <cmath>
#include "BeamPropagator.hpp"
#include <unistd.h>
#include <cstring>
#include <vector>
#include <fstream>
#include "modes.hpp"
#include <memory>

const int CELLS = 256;
const float LAMBDA = 500.0e-9;
const float DZ = LAMBDA * 16;
const float CELL_DIM = LAMBDA;
const int RENDER_EVERY = 30;

void displayModalSpectrum(af::array p)
{
	float avg = af::mean<float>(p);
	float* ph = p.host<float>();
	int lbound = 0, ubound = p.dims(0) - 1;
	for(; lbound < p.dims(0) && ph[lbound] < avg; lbound++);
	for(; ubound > 0 && ph[ubound] < avg; ubound--);
	af::freeHost(ph);
	
	int steps = 2 * p.dims(0);
	p = p(af::seq((double)lbound, (double)ubound));
	af::array x = 2 * af::Pi * af::seq(lbound, ubound + 1) / (steps * DZ);
	af::Window w(2000, 1000);
	while(!w.close())
	{
		w.plot(x, p);
	}
}

void displayTiledModes(const ModesAnalysisConfig& cfg, af::array modes)
{
	std::unique_ptr<BeamPropagator<float>[]> bps(new BeamPropagator<float>[modes.dims(2)]);
	
	for(int i = 0; i < modes.dims(2); i++)
	{
		bps[i] = BeamPropagator<float>(cfg.cell_count, cfg.cell_dim, cfg.lambda);
		bps[i].setMask(cfg.mask);
		bps[i].setElectricField(modes.slice(i));
	}
	
	int cols = std::ceil(std::sqrt(modes.dims(2)));
	int rows = modes.dims(2) / cols;
	rows += rows * cols != modes.dims(2);
	af::Window wnd(cols * cfg.cell_count, rows * cfg.cell_count);
	wnd.grid(rows, cols);
	while(!wnd.close())
	{
		for(int i = 0; i < modes.dims(2); i++)
		{
			bps[i].step(cfg.dz);
		}
		for(int i = 0; i < modes.dims(2); i++)
		{
			af::array tmp = af::abs(bps[i].getElectricField()).as(f32);
			wnd(i / cols, i % cols).image(tmp / af::max<float>(tmp));
		}
		wnd.show();
	}
}

int main()
{
	af::setBackend(AF_BACKEND_CUDA);
	af::info();
	
	af::array efld = af::range(CELLS) - CELLS / 2;
	efld *= efld;
	efld = af::tile(efld, 1, CELLS) + af::tile(efld.T(), CELLS);
	efld = af::exp(-efld / 1000.0);
	
	af::array mask = af::constant(1.45, af::dim4(CELLS, CELLS));
	af::seq in_guide(49, CELLS - 50);
	mask(in_guide, in_guide) = 1.46;
	
	std::cout << in_guide.size * CELL_DIM << std::endl;
	
//	ModesAnalysisConfig cfg;
//	cfg.dz = DZ;
//	cfg.steps = std::ceil(0.1 / DZ);
//	cfg.cell_dim = CELL_DIM;
//	cfg.cell_count = CELLS;
//	cfg.initial_field = efld;
//	cfg.lambda = LAMBDA;
//	cfg.mask = mask;
//	
//	af::array spectrum = modesComputeSpectrum<float>(cfg);
//	displayModalSpectrum(spectrum);
//	
//	spectrum *= spectrum > af::shift(spectrum, -1) && spectrum > af::shift(spectrum, 1);
//	af::array betas;
//	af::sort(spectrum, betas, spectrum, 0, false);
//	
//	int nmodes = 1;
//	nmodes = std::min(nmodes, af::count<int>(spectrum));
//	spectrum = af::array();
//	betas = betas(af::seq(nmodes));
//	betas = modesSpectralIndexToBeta(betas, cfg);
//	
//	af::array modes = modesComputeFunctions<float>(cfg, betas);
//	//displayTiledModes(cfg, modes);
//	
//	af::saveArray("first_mode", modes.slice(0), "first_mode.arr", false);
	
//	efld = af::readArray("first_mode.arr", "first_mode").as(c64);
//	efld /= af::max<double>(af::abs(efld));
	
	BeamPropagator<double> bp(CELLS, LAMBDA, CELL_DIM);
	//bp.setElectricField(modes.slice(0));
	bp.setElectricField(efld);
	bp.enableAbosrbingBoundaries();
	bp.setMask(mask);
	
	af::Window wnd(CELLS, CELLS);
	
	double e0 = -1.0;
	
	while(!wnd.close() && bp.getZ() < 0.5)
	{
		af::array ef = af::abs(bp.getElectricField());
		
		af::array in = ef(in_guide, in_guide);
		in *= in;
		double e = af::sum<double>(in) * CELL_DIM * CELL_DIM;
		if(e0 < 0)
			e0 = e;
		
		std::cout << bp.getZ() << "," << (e / e0) << std::endl;
		
		ef = ef.as(f32);
		wnd.image(ef / af::max<float>(ef));
		
		for(int i = 0; i < 5000; i++)
			bp.step(DZ);
	}
	
	return 0;
}

